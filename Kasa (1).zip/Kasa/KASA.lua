--####                                  ####
--##    Kourtneys Awesome Spell Addon     ##
--####                                  ####
--##The aim of this addon is to track the combat log for every "Casts (spellname)" registered from the 4 events below: 
--##"CHAT_MSG_SPELL_SELF_DAMAGE"
--##"CHAT_MSG_SPELL_FRIENDLYPLAYER_DAMAGE"
--##"CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE"
--##"CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE"
--##If any of the 3 first events happen then a raid mark should be placed on whoever cast the spell (E.g. a skull).
--##If the event "CHAT_MSG_SPELL_SELF_DAMAGE" happens then it should also post in /say "Spellname" on me.
--##If the event "CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE" happens you will be told that you are taking damage from (spellname).


-- Core Functions -------------------------------------------------------------------

local function kprint(text, red, green, blue, alpha)
    DEFAULT_CHAT_FRAME:AddMessage(text, red, green, blue, alpha)
end

local function kasa_addonLoaded()
    kprint("Kourtney's Awesome Spell Addon Loaded!")
end

local function registerEvents(frame, events)
    for key, value in pairs(events) do
        frame:RegisterEvent(key)
    end
end

local function unregisterEvents(frame, events)
    for key, value in pairs(events) do
        frame:UnregisterEvent(key)
    end
end

-- Event Frames ---------------------------------------------------------------------

local kasa_main_frame = CreateFrame("Frame")
local kasa_main_events = {}

local kasa_combatLog_frame = CreateFrame("Frame")
local kasa_combatLog_events = {}

-- User Interface Frames ------------------------------------------------------------

local kasa_warningMessageFrame = CreateFrame("MessageFrame")
kasa_warningMessageFrame:SetPoint("TOP",UIParent)
kasa_warningMessageFrame:SetWidth(400)
kasa_warningMessageFrame:SetHeight(100)
kasa_warningMessageFrame:SetFont("Fonts\\FRIZQT__.TTF", 14, "1")
kasa_warningMessageFrame:Show()


local kasa_enabled = true

function kasa_enable()
    if not kasa_enabled then
        registerEvents(kasa_combatLog_frame, kasa_combatLog_events)
        kasa_warningMessageFrame:Show()
        kasa_enabled = true
        kprint("KASA Enabled")
    else
        kprint("KASA is already Enabled")
    end 
end

function kasa_disable()
    if kasa_enabled then
        unregisterEvents(kasa_combatLog_frame, kasa_combatLog_events)
        kasa_warningMessageFrame:Hide()
        kasa_enabled = false
        kprint("KASA Disabled")
    else
        kprint("KASA is already Disabled")
    end
end


-- Spell Detection Functions --------------------------------------------------------

local groundEffectSpells = {"Void Zone", "Shadow Fissure"}

function detectGroundEffectSpells(combatLogText)
    _,_,casterName,spellName = string.find(combatLogText, "(%a+)%scasts?%s(.+)\.")
    casterName = casterName or ""
    spellName = spellName or ""
    --kprint("playerName: "..playerName.." - spellName: "..spellName)
    for i = 1, table.getn(groundEffectSpells) do
        if spellName == groundEffectSpells[i] then
            if casterName == "You" then
                casterName = UnitName("player")
                SendChatMessage(groundEffectSpells[i].." on me! ("..casterName..")", "SAY")
            end
            previousTarget = UnitName("target")
            TargetByName(casterName)
            SetRaidTarget("target", 8)
            if previousTarget ~= casterName then
                TargetLastTarget()
            end
        end
    end
end

function detectVoidZoneConsumptions(combatLogText)
    if string.find(combatLogText, "Void Zone.*hits") then
        kasa_warningMessageFrame:AddMessage("Standing in a Void Zone!", 0.7,0.4,1.0)
        kprint("Standing in a Void Zone!", 0.7,0.4,1.0)
    end
end


-- Events - Main --------------------------------------------------------------------

function kasa_main_events:ADDON_LOADED(addonName)
    if addonName == "KASA" then
        kasa_addonLoaded()
        kasa_main_frame:UnregisterEvent("ADDON_LOADED")
    end
end

registerEvents(kasa_main_frame, kasa_main_events)

function kasa_main_eventHandler()
    kasa_main_events[event](kasa_main_events, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
end

kasa_main_frame:SetScript("OnEvent", kasa_main_eventHandler)


-- Events - CombatLog ---------------------------------------------------------------

function kasa_combatLog_events:CHAT_MSG_SPELL_SELF_DAMAGE(combatLogText)
    detectGroundEffectSpells(combatLogText)
end

function kasa_combatLog_events:CHAT_MSG_SPELL_FRIENDLYPLAYER_DAMAGE(combatLogText)
    detectGroundEffectSpells(combatLogText)
end

function kasa_combatLog_events:CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE(combatLogText)
    detectGroundEffectSpells(combatLogText)
end

function kasa_combatLog_events:CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE(combatLogText)
    detectVoidZoneConsumptions(combatLogText)
end

registerEvents(kasa_combatLog_frame, kasa_combatLog_events)

function kasa_combatLog_eventHandler()
    kasa_combatLog_events[event](kasa_combatLog_events, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
end

kasa_combatLog_frame:SetScript("OnEvent", kasa_combatLog_eventHandler)



-- Slash Commands -------------------------------------------------------------------

SLASH_KASA1 = "/kasa"
SLASH_KASA2 = "/KASA"
SlashCmdList["KASA"] = function(Flags)
    flags = string.lower(Flags);
    words = {};
    for word in string.gfind(flags, "[^%s]+") do
        table.insert(words, word);
    end
    
    if words[1] == "on" then
        kasa_enable() 
    elseif words[1] == "off" then
        kasa_disable()
    end
end

